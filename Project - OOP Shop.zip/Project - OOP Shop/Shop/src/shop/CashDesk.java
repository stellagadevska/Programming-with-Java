package shop;

public class CashDesk {
    // съхранява информация за това кой касиер работи в момента на тази каса.
    private Cashier operatingCashier;


    public CashDesk(Cashier operatingCashier) {
        this.operatingCashier = operatingCashier;
    }

    public Cashier getOperatingCashier() {
        return operatingCashier;
    }

    // На касата клиентите в магазина плащат за закупените стоки и получават касова бележка.

}
