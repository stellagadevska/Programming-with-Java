package shop;

public class Cashier {
    // съхранява информация за идентификационен номер и име на касиера
    private int id = 100;
    private String name;

    public Cashier(String name) {
        id++;
        this.name = name;
    }

//    public void removeCashier() {
//        id--;
//    }

    public int getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Cashier{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
