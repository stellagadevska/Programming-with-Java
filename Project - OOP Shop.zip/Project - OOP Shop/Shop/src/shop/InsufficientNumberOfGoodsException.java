package shop;

public class InsufficientNumberOfGoodsException extends Exception {
    private int numberOfGoods;
    private Goods goods;

    public InsufficientNumberOfGoodsException(Goods goods, int numberOfGoods) {
        super("За съжаление в магазина не достигат " + (numberOfGoods - goods.getQuantity()) + " бройки от "
                + goods.getName());
    }

    public int getNumberOfGoods() {
        return numberOfGoods;
    }

    @Override
    public String toString() {
        return "InsufficientNumberOfGoodsException{" +
                "numberOfGoods=" + numberOfGoods +
                '}';
    }
}
