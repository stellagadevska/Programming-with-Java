package shop;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Creating a Shop
        Shop shop = new Shop("Слънце");

        System.out.println("Добре дошли в магазин '" + shop.getName() + "'.");

        boolean quit = false;
        int choice = 0;

        while (!quit) {
            chooseRole();
            String makeAChoice = "Въведете вашия избор: ";
            System.out.print(makeAChoice);
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    System.out.print("Вие сте влезли като 'Управител'.");
                    printInstructionsManager();
                    System.out.println(makeAChoice);
                    choice = Integer.parseInt(scanner.nextLine());
                    switch (choice) {
                        case 1:
                            System.out.println("Показване на работещи каси...");
                            System.out.println("Брой работещи каси: " + shop.getCashiersList().size());

                           try {
                               for (Cashier cashier : shop.getCashiersList()) {
                                   System.out.println(cashier);

                                   Thread thread = new Thread(shop);

                                   Thread.sleep(1000);
                                   thread.start();
                               }
                           } catch (InterruptedException e) {
                               e.printStackTrace();
                           }

                            break;
                        case 2: {
                            System.out.println("Добавяне на касиер...");

                            System.out.println("Име на касиер: ");
                            String name = scanner.nextLine();

                            Cashier cashier = new Cashier(name);
                            if (shop.canAddCashier(cashier)) {
                                shop.addCashier(cashier);
                                System.out.printf("Касиерът %s (ID: %d) отваря каса No%d.%n", cashier.getName(), cashier.getID(), shop.getCashiersList().size());
                            } else {
                                System.out.println("Не може да се добави касиер, който вече работи в магазина.");
                            }
                        }

                        break;
                        case 3: {
                            System.out.println("Премахване на касиер...");

                            System.out.println("Име на касиер: ");
                            String name = scanner.nextLine();

                            Cashier cashier = new Cashier(name);
                            if (shop.canRemoveCashier(cashier)) {
                                System.out.printf("Касиерът %s е уволнен от магазина.%n", cashier.getName());
                                shop.removeCashier(cashier);
                            } else {
                                System.out.println("Не може да премахнете касиер, който не работи в магазина.");

                            }
                        }

                        break;
                        case 4:
                            System.out.println("Друг избор: ");
                            continue;
                    }
                    break;
                case 2:
                    System.out.println("Вие сте влезли като 'Доставчик'.");
                    printInstructionsDeliverer();
                    choice = scanner.nextInt();
                    switch (choice) {
                        case 1:
                            System.out.println("Проверка на налични продукти в магазина...");
                            shop.printGoods();
                            break;
                        case 2:
                            System.out.println("Доставяне на продукт...");
                            System.out.println("Въведете продукт за доставка: ");

//                            Goods goods = new Goods();
                            break;
                        case 3:
                            System.out.println("Друг избор: ");
                            continue;
                    }
                    break;
                case 3:
                    System.out.println("Вие сте влезли като 'Клиент'.");
                    System.out.println("Въведете вашето име: ");
                    String name = scanner.nextLine();
                    System.out.println("Въведете вашия бюджет: ");
                    double budget = Double.parseDouble(scanner.nextLine());

                    Client client = new Client(name, budget);

                    printInstructionsClient();
                    System.out.println(makeAChoice);
                    choice = Integer.parseInt(scanner.nextLine());
                    switch (choice) {
                        case 1:
                            System.out.println("Проверка на налични продукти...");
                            shop.printGoods();
                            break;
                        case 2:
                            System.out.println("Добавяне на продукт...");
                            System.out.println("Въведете продукт и количество: ");
                            String product = scanner.nextLine();
                            int quantity = Integer.parseInt(scanner.nextLine());

                            Goods goods = new Goods(product, quantity);
                            client.addGoodsToCart(shop, goods, quantity);
                            break;
                        case 3:
                            System.out.println("Премахване на продукт...");
//                            client.removeGoodsFromCart(goods);
                            break;
                        case 4:
                            System.out.println("Плащане...");

                            System.out.println("Избирам каса номер: ");
                            choice = Integer.parseInt(scanner.nextLine());

                            Cashier cashier = (shop.getCashiersList().get(choice - 1));

                            Receipt receipt = new Receipt(4559, cashier);
                            Goods goods1 = new Goods("мляко", 2);
                            Goods goods2 = new Goods("домат", 3);
                            Goods goods3 = new Goods("картоф", 6);

                            String filename = "files/GoodsData.txt";
//
                            Receipt.writeReceipt(filename, cashier, goods1);

                            client.pay();
                            break;
                        case 5:
                            System.out.println("Промени роля...");
                            continue;
                    }
                    break;
                default:
                    System.out.println("Довиждане!");
                    quit = true;
                    break;
            }
        }
    }

    public static void chooseRole() {
        System.out.println("\nВлез като: ");
        System.out.println("\t 1. Управител (наеми касиери, провери оборот)");
        System.out.println("\t 2. Доставчик (достави продукти)");
        System.out.println("\t 3. Клиент (купи продукти)");
        System.out.println("\t 4. Излез от магазина.");
    }

    public static void printInstructionsManager() {
        System.out.println("\nИзберете едно от следните: ");
        System.out.println("\t 1. Покажи работещите каси.");
        System.out.println("\t 2. Наеми нов касиер.");
        System.out.println("\t 3. Освободи (премахни) касиер.");
        System.out.println("\t 4. Провери оборот.");
        System.out.println("\t 5. Промени роля.");
    }

    public static void printInstructionsDeliverer() {
        System.out.println("\nИзберете едно от следните: ");
        System.out.println("\t 1. Провери налични продукти.");
        System.out.println("\t 2. Доставяне на продукт. ");
        System.out.println("\t 3. Промени роля.");
    }

    public static void printInstructionsClient() {
        System.out.println("\nИзберете едно от следните: ");
        System.out.println("\t 1. Провери налични продукти.");
        System.out.println("\t 2. Добави продукт към количката.");
        System.out.println("\t 3. Премахни продукт от количката.");
        System.out.println("\t 4. Извърши плащане.");
        System.out.println("\t 5. Промени роля.");
    }

}

//                            Goods goods1 = new Goods("meat", 15);
//                            Goods goods2 = new Goods("butter", 6);
//                            Goods goods3 = new Goods("milk", 2);

//                            String filename = "files/GoodsData.txt";
//                            writeGoods(filename, goods1);
//                            writeGoods(filename, goods2);
//                            writeGoods(filename, goods3);