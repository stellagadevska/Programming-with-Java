package shop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Shop implements Runnable {
    //  съхранява информация за списък със стоки, които се продават в магазина, списък с касиери, които работят в
    //  магазина и брой на издадените касови бележки.
    private String name;
    private Map<Goods, Integer> goodsInShop;
    private List<Cashier> cashiersList;
    private double totalIncome;

    // Constructor - creating an object with name
    public Shop(String name) {
        this.name = name;
        this.goodsInShop = new HashMap<Goods, Integer>();
        this.cashiersList = new ArrayList<>();
        this.totalIncome = 0.00;
    }

    public String getName() {
        return name;
    }

    public Map<Goods, Integer> getGoodsInShop() {
        return goodsInShop;
    }

    public List<Cashier> getCashiersList() {
        return cashiersList;
    }

    public String setLastCashierName() {
        String lastCashierName = "";
        if (cashiersList.size() == 1) {
            Cashier lastCashier = (cashiersList.get(0));
            lastCashierName = lastCashier.getName();
        } else if (cashiersList.size() > 1) {
            Cashier lastCashier = (cashiersList.get(cashiersList.size() - 1));
            lastCashierName = lastCashier.getName();
        }
        return lastCashierName;
    }

    // Наемане/ Добавяне на касиер
    public boolean canAddCashier(Cashier cashier) {
        return !cashier.getName().equals(setLastCashierName());
    }

    public void addCashier(Cashier cashier) {
        cashiersList.add(cashier);
    }

    // Уволняване/ Премахване на касиер
    public boolean canRemoveCashier(Cashier cashier) {
        return cashier.getName().equals(setLastCashierName());
    }

    public void removeCashier(Cashier cashier) {
        cashiersList.remove(cashier);
    }

    // Доставка на стоки.
    public void deliverGoods(Goods goods, int quantity) {
        goodsInShop.put(goods, quantity);
    }

    // 1. При продажба на стока, да се проверява дали има достатъчно налично количество от нея. Ако количеството не е
    // достатъчно да се хвърля изключение. Изключението да показва от коя стока какво количество не достига, за да се
    // извърши покупката.
    // Продажба на стоки
    // Трябва да може да се осъществи продажбата на стока, ако има достатъчно налично количество от нея в магазина.
    public void sellGoods(Goods goods, int quantity) throws InsufficientNumberOfGoodsException {
        if (!goodsInShop.containsKey(goods)) {
            System.out.println("Няма такъв продукт в магазина.");
            throw new InsufficientNumberOfGoodsException(goods, quantity);
        } else {
            if (goodsInShop.containsKey(goods)) {
                if (goodsInShop.get(goods) == 1) {
                    goodsInShop.remove(goods);
                }
            } else {
                goodsInShop.put(goods, goodsInShop.get(goods) - quantity);
            }
        }
    }

    // Print goods
    public void printGoods() {
        for (Map.Entry<Goods, Integer> entry : goodsInShop.entrySet()) {
            Goods key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + " - " + value + " броя.");
        }
    }

    // Проверка на общия оборот на магазина към момента.
    public double checkCurrentIncome() {
        return this.totalIncome;
    }


    @Override
    public void run() {

        for (int i = 1; i <= cashiersList.size(); i++) {
            System.out.println("Каса: " + " i " + Thread.currentThread().getName()
                    + " Kасиер: " + cashiersList.get(i) + " .");
        }
//        System.out.println(Thread.currentThread().getName() + " завърши");
    }


    // 2. В магазина всички каси работят паралелно. Да се осъществи работата на касите в отделни нишки. Да се показва
    // информация за това кой касиер работи на касата в момента и общата стойност на всяка издадена касова бележка.


    @Override
    public String toString() {
        return "Shop{" +
                "name='" + name + '\'' +
                ", goodsInShop=" + goodsInShop +
                ", cashiersList=" + cashiersList +
                ", totalIncome=" + totalIncome +
                '}';
    }
}
