package shop;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Receipt {
    // информация за пореден номер, касиер, който издава касовата бележка, дата и час на издаване на касовата бележка,
    // списък със стоки, които се включват в касовата бележка включително цената и количеството им.
    private long serialNumber;
    private Cashier operatingCashier;
    private LocalDateTime dateAndHour;
    private List<Goods> goodsList;

    // Необходимо е да се съхранява общия брой на издадените касови бележки до момента и общата сума, която се генерира
    // като оборот при издаването.
    private int totalNumberOfReceipts;
    private double totalSumGenerated;

    public Receipt(long serialNumber, Cashier operatingCashier) {
        this.serialNumber = serialNumber;
        this.operatingCashier = operatingCashier;
        this.dateAndHour = LocalDateTime.now();
        this.goodsList = new ArrayList<>();

        this.totalNumberOfReceipts = 0;
        this.totalSumGenerated = 0.00;
    }

    public void addItemToReceipt(Goods goods, Shop shop) {
        goodsList.add(goods);
//        shop.sellGoods();
    }

    public static void writeReceipt(String outputFilename, Cashier cashier, Goods goods) {
        File filesDirectory = new File("files");

        String filename = "files/ReceiptsData.txt";

        FileWriter fout = null;
        try {
            fout = new FileWriter(new File(outputFilename), true);
            if (cashier != null) {
                fout.append(cashier.toString()).append(System.lineSeparator());
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found " + e);
        } catch (IOException e) {
            System.out.println("IOException " + e);
        } finally {
            try {
                if (fout != null) {
                    fout.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb
                .append("__________________________________________" + "\n")
                .append("|____________Магазин Слънце_______________|" + "\n")
                .append("|Номер на касова бележка " + this.serialNumber + "|\n")
                .append("|Касиер:                           " + this.operatingCashier + "|\n")
                .append("|Date and time:       " + this.dateAndHour + "|\n");

        int prodCount = 1;

        for(Goods goods : goodsList) {
            sb.append("| " + prodCount + ". " + goods.getName() + ": " + Math.round(goods.getSinglePrice()* 100.0) / 100.0 + "\n");
            prodCount++;
            totalSumGenerated += goods.getSinglePrice();
        }
        sb
                .append("|Цена:                          " + Math.round(this.totalNumberOfReceipts* 100.0) / 100.0 + " leva.| \n")
                .append("| Благодарим, че избрахте магазин Слънце! |\n")
                .append("|_________________________________________|\n");
        return sb.toString().trim();
    }

    // При издаването на касовата бележка е необходимо нейното съдържание да се показва и да се запазва във файл.
    // Всяка касова бележка трябва да се пази в отделен файл с име на файла, което да съдържа поредния номер на
    // издадената касова бележка. Трябва да може да се провери колко са издадените касови бележки към момента.
    // Информацията във файла, в който се записва касовата бележка трябва да може да се прочете.


}
