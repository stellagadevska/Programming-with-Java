package shop;

import java.awt.dnd.InvalidDnDOperationException;
import java.util.ArrayList;
import java.util.List;

public class Client {
    private String name;
    private double budget;
    private double purchaseSum;
    private List<Goods> shoppingCart;

    public Client(String name, double budget){
        this.name = name;
        this.budget = budget;
        this.purchaseSum = 0;
        this.shoppingCart = new ArrayList<Goods>();
    }


    public void addGoodsToCart(Shop shop, Goods goods, int quantity) {
        try {
            shop.sellGoods(goods, quantity);
        } catch (InsufficientNumberOfGoodsException e) {
            e.printStackTrace();
        }

        if (budget < purchaseSum + goods.getSinglePrice()) {
            System.out.println("Съжаляваме, но парите за " + goods.getName() + " не Ви достигат.");
            System.out.println("Недостигащи пари: " + (goods.getSinglePrice() - getBudget()) + "лв.");
        } else {
            shoppingCart.add(goods);
            // Добавяме към сумата за покупката
            purchaseSum += goods.getSinglePrice();
            System.out.println("Продуктът: " + goods + " бе добавен в количката.");
            System.out.println("");
        }
    }

    public void removeGoodsFromCart(Goods goods){
        shoppingCart.remove(goods);
        // Премахваме от сумата за покупката
        purchaseSum -= goods.getSinglePrice();
        System.out.println("Продуктът: " + goods + " бе премахнат от количката.");
    }

    public String getName() {
        return name;
    }

    public double getBudget() {
        return budget;
    }

    public List<Goods> getShoppingCart() {
        return shoppingCart;
    }

    public void pay() {
        this.budget -= purchaseSum;
    }

    @Override
    public String toString() {
        return "Client{" +
                "name='" + name + '\'' +
                ", budget=" + budget +
                ", shoppingCart=" + shoppingCart +
                '}';
    }
}
