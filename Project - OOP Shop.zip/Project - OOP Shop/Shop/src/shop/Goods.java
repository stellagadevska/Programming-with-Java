package shop;

import java.awt.dnd.InvalidDnDOperationException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class Goods {
    // съхранява идентификационен номер, име, единична цена на стоката и срок на годност
    private static int ID;
    private String name;
    private double singlePrice;
    private int quantity;
    private LocalDateTime expirationDate;

    public Goods(String name, double singlePrice) {
        ID = 1;
        this.name = name;
        this.singlePrice = singlePrice;
        ID++;
//        this.expirationDate = LocalDateTime.of(date, time);
    }

    public Goods(String name, int quantity) {
        this.name = name;
        ID++;
    }

    public int getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getSinglePrice() {
        return singlePrice;
    }

    public LocalDateTime getExpirationDate() {
        return expirationDate;
    }

    // Метод, чрез който се продава стоката.
    public boolean sellGoods(Client client, Goods goods) {
        if (expirationDate.isBefore(LocalDateTime.now())) {
            client.pay();
            return true;
        } else {
            return false;
        }
    }

}
